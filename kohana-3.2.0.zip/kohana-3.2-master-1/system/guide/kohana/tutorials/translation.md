

<http://kerkness.ca/wiki/doku.php?id=routing:static_pages>

<http://kerkness.ca/wiki/doku.php?id=routing:multi-language_with_a_route>