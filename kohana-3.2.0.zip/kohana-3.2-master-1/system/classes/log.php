<?php defined('SYSPATH') or die('No direct script access.');

class Log extends Kohana_Log {}