<?php defined('SYSPATH') or die('No direct script access.');

class Database_Expression extends Kohana_Database_Expression {}
