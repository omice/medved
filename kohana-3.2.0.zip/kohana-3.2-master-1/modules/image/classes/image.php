<?php defined('SYSPATH') or die('No direct script access.');

abstract class Image extends Kohana_Image {}
