# Kohana PHP Framework, version 3.2 (development)

This is the current development version of [Kohana](http://kohanaframework.org/).

For the most current release, see the 3.1/master branch.
